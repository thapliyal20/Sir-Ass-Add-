package com.edms.bean;

import java.util.Date;

public class EmployeeBean {
	
	private String Emp_Id;
	private String Emp_firstName;
	private String Emp_lastName;
	private long Emp_ContactNumber;
	private Date Emp_doj;
	private String Emp_Email;
	
	public String getEmp_Id() {
		return Emp_Id;
	}
	public void setEmp_Id(String emp_Id) {
		Emp_Id = emp_Id;
	}
	public String getEmp_firstName() {
		return Emp_firstName;
	}
	public void setEmp_firstName(String emp_firstName) {
		Emp_firstName = emp_firstName;
	}
	public String getEmp_lastName() {
		return Emp_lastName;
	}
	public void setEmp_lastName(String emp_lastName) {
		Emp_lastName = emp_lastName;
	}
	public long getEmp_ContactNumber() {
		return Emp_ContactNumber;
	}
	public void setEmp_ContactNumber(long emp_ContactNumber) {
		Emp_ContactNumber = emp_ContactNumber;
	}
	public Date getEmp_doj() {
		return Emp_doj;
	}
	public void setEmp_doj(Date emp_doj) {
		Emp_doj = emp_doj;
	}
	public String getEmp_Email() {
		return Emp_Email;
	}
	public void setEmp_Email(String emp_Email) {
		Emp_Email = emp_Email;
	}

	
}
