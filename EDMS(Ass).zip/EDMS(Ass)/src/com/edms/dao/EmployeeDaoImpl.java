package com.edms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.edms.bean.EmployeeBean;
import com.edms.exception.EmployeeException;
import com.edms.util.DBConnection;

public class EmployeeDaoImpl implements EmployeeDao{

	private int getempId(){
		int id=0;
		Connection con=null;
		try {
			con=DBConnection.getConnection();
			String qry="Select emp_id_seq.nextval from dual";
			Statement stmt=con.createStatement();
			ResultSet rst = stmt.executeQuery(qry);
			rst.next();
			id=rst.getInt(1);
		} catch (EmployeeException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return id;
	}
	
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException 
	 {
		Connection con=null;
	
		int id=0;
		try {
			con=DBConnection.getConnection();
			id = getempId();
			String cmd="Insert into employee_tbl "
					+ "(emp_id, emp_firstname, emp_lastname, emp_contactnumber, emp_doj, emp_email)"
					+ "values(?,?,?,?,sysdate,?)";
			PreparedStatement pst= con.prepareStatement(cmd);
			pst.setString(1,String.valueOf(id));
			pst.setString(2, bean.getEmp_firstName());
			pst.setString(3, bean.getEmp_lastName());
			pst.setLong(4, bean.getEmp_ContactNumber());
			//pst.setString(5, String.valueOf(bean.getEmp_doj()));
			pst.setString(5, bean.getEmp_Email());
			pst.executeUpdate();
			System.out.println("Employee added Successfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public EmployeeBean viewEmployeeId(int id)throws EmployeeException {
		return null;
	}
		
	

}
