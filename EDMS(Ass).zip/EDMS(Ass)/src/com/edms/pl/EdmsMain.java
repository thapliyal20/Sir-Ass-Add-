package com.edms.pl;

import java.util.Scanner;

import com.edms.bean.EmployeeBean;
import com.edms.exception.EmployeeException;
import com.edms.service.EmployeeService;
import com.edms.service.EmployeeServiceImpl;

public class EdmsMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int id=0;
		EmployeeBean bean=new EmployeeBean();
		EmployeeService service=new EmployeeServiceImpl();
		
		try {
			System.out.println("Enter the First name: ");
			String fname=sc.next();
			bean.setEmp_firstName(fname);
			
			System.out.println("Enter the last name: ");
			String lname=sc.next();
			bean.setEmp_lastName(lname);
			
			System.out.println("Enter the number: ");
			long number=sc.nextLong();
			bean.setEmp_ContactNumber(number);
			
			System.out.println("Enter the mail id: ");
			String mail=sc.next();
			bean.setEmp_Email(mail);
			
			id=service.addEmployee(bean);
			System.out.println("id: "+id);
		} catch (EmployeeException e) {
			e.printStackTrace();
		}
		

	}

}
