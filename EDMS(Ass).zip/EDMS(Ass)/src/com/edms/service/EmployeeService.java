package com.edms.service;

import com.edms.bean.EmployeeBean;
import com.edms.exception.EmployeeException;

public interface EmployeeService {
	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	public EmployeeBean viewEmployeeId(int id) throws EmployeeException;
	
}
