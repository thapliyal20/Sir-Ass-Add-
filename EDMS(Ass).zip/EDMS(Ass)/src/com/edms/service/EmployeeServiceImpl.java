package com.edms.service;

import com.edms.bean.EmployeeBean;
import com.edms.dao.EmployeeDao;
import com.edms.dao.EmployeeDaoImpl;
import com.edms.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
EmployeeDao employeeDao=new EmployeeDaoImpl();
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id = employeeDao.addEmployee(bean);
		return id;
	}

	@Override
	public EmployeeBean viewEmployeeId(int id) throws EmployeeException {
		return null;
	}

}
